# PyMLScaffold/__init__.py

# Importer la fonction de création de projet depuis create_project.py
from .create_project import create_project_structure
