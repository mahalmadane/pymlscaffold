from pymlscaffold.create_project import create_project_structure

create_project_structure("mon_projet_ml")
