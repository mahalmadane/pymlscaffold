pymlscaffold

pymlscaffold est une bibliothèque Python permettant de créer rapidement une structure de projet standardisée pour les projets de Machine Learning. Elle génère tous les dossiers et fichiers nécessaires pour démarrer ton projet ML de manière organisée.

Installation
1. Installer via pip :
pip install pymlscaffold

2. Installation depuis le code source :
git clone https://github.com/ton-utilisateur/pymlscaffold.git
cd pymlscaffold
pip install .

Utilisation
Créer un projet ML

Une fois le package installé, tu peux créer une structure de projet comme suit :

from pymlscaffold.create_project import create_project_structure

# Créer un projet appelé "mon_projet_ml"
create_project_structure("mon_projet_ml")


Cela va générer une arborescence de répertoires pour un projet ML complet.

Structure du projet

Après avoir exécuté la commande ci-dessus, ton projet aura la structure suivante :

mon_projet_ml/
│
├── README.md                  # Explication du projet
├── requirements.txt           # Liste des dépendances
├── setup.py                   # Script d'installation
├── .gitignore                 # Fichiers à ignorer par Git
│
├── data/                      # Données
│   ├── raw/                   # Données brutes
│   ├── interim/               # Données traitées
│   └── processed/             # Données prêtes pour l'entraînement
│
├── notebooks/                 # Notebooks d'expérimentation
│   ├── 01_exploration.ipynb
│   ├── 02_preprocessing.ipynb
│   └── 03_model_training.ipynb
│
├── src/                       # Code source
│   ├── data/                  # Chargement et prétraitement des données
│   ├── features/              # Ingénierie des features
│   ├── models/                # Entraînement et évaluation des modèles
│   ├── utils/                 # Fonctions utilitaires
│   └── pipelines/             # Pipelines pour ZenML, MLflow, etc.
│
├── tests/                     # Tests unitaires
│   ├── test_data.py
│   └── test_model.py
│
├── reports/                   # Graphiques et métriques
│
├── configs/                   # Fichiers de configuration
│
├── scripts/                   # Scripts d'exécution du projet